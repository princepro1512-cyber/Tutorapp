# የቱቶር ተማሪዎች መመዝገቢያ (PWA)

ፋይሎች: index.html, config.js, sw.js, manifest.webmanifest, icon files, firestore.rules

## 1. Firebase
1. console.firebase.google.com → Add project
2. Build → Authentication → Get started → Email/Password ያብሩ
3. Build → Firestore Database → Create database (production mode)
4. Firestore → Rules → የ firestore.rules ይዘት ይለጥፉ → Publish
5. Project settings → Your apps → Web (</>) → የሚሰጥዎትን config በ config.js ውስጥ ይተኩ

## 2. GitHub
አዲስ repository ይክፈቱ → ሁሉንም ፋይሎች (ከዚፑ ውስጥ አውጥተው) ይጫኑ።

## 3. EdgeOne Pages
1. EdgeOne Pages → Create project → Import Git repository → repo ይምረጡ
2. Build command: ባዶ ይተዉ፣ Output directory: ባዶ (root)
3. Deploy ይጫኑ → ሊንክ ያገኛሉ

## 4. የመጨረሻ እርምጃ (አስፈላጊ)
Firebase → Authentication → Settings → Authorized domains → የEdgeOne ዶሜይንዎን ያክሉ።
ያለዚህ መግባት አይሰራም።
